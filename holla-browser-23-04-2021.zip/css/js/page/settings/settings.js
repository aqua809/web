document.getElementById('version').innerText = sendSync('getVersions').holla;
document.getElementById('dowloandsHEdef').innerText = sendSync('dowloandsHEdef');

/* Tema Çek Yükle */
function xloadThemes(){
const theme = sendSync('getTheme');

if(theme != 'light') {
if(document.querySelector("link[rel*='shortcut icon']")) document.querySelector("link[rel*='shortcut icon']").remove();
document.head.insertAdjacentHTML('beforeend',`<link rel="stylesheet" href="assets://themes/dark.css">`);
document.head.insertAdjacentHTML('beforeend',`<link rel="shortcut icon" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAADF0lEQVR4Ae3YAWQjWRgA4CAIgqBYLIpFERRFcSjFoQiKYrEoDkURLIpFURRFURSHYHGA4lAEh2CxKIIiCIIgCILgO4D5ZeaZ2cQK8gHy4vn/efPm/9+rbc7Ozg7uQVp3W4P/pLz6Nibwp/IOtjGBK+WdbWMCD6I77GMf30XX25jAi+g8M/ZV9Pg7AzvBDzyinTPewDVmMrL/xYVojC95mxnH+BuDtfcKGngXDfAFDZxhLF8jM8+RfEMco4UrvIn+WzeBG8Xmio3jPFqKLbFQ7POvBv8Bc9XMcI+DxKuxUM0YjVpV6IkWii3wDa2SD+YpPZel6LZq8MdWXWIfd5gA4A3tWkU4jfMYoos93IkW2K8y+UD0M/vFQB0XuEMzp6W4xQAjjNDHDT7krMYDTuPvmpiIvpcN/syqlxBoEJJ6xFKxBW5KvmY/REqtNNryveFTIvi+8nq1AjjC2Kol9qqswtyqeV4fg2dV5awELgtWcILj6u0xb/IdZf53aNUYl2jjsKBSL7J7Aufy9TP/qwZN9KxqJ57+KO9ziv2cJG7Se8/9Rs4OWIqambGRqJOY51rUT+y999qmEKXGUsUMh6JRWKGcsbWhXjGBZmKug6KeCR8LxtaHRaLTnIhOE/NcigaJ5Iabevq3qTMteqmqHTtSY9Ft4ky9xNU6we/hVb4/4oGHnCRO0UQLHYxEy2xhxGf5eukuoHo17CaOk1U8plebdBeQ3mgLqyY4SdSLofL6Rd93dDC3apZu1+MERAPS1RDNkivxjHqJLmBo1WHZjTsUvRa8ZlfEYHCCHiaxOnvGYcGFQDsnhvd0DNVv2Tpo4q/Y6npNr07yKf+Mr5ULNNAVLSsfmvCvaIqZfNNwTZKQCXCemGsuevrVy9qlat7RRavgkPIVE2npzbvJ6/KEcbohrGStYtbCRDTGN3zEVeJVaJS4ep/iHAe4x1T0tnY7jQ6meMEZ6gUH84WonfgozPKuYdDABfqYZCv++qpv+k7iHPBU2zZ4FHXTY1sG18rrbGMCZ8prb2MCB8prbGMCdfwjDR5qG7Ozs/M/Jk8uNWWxg+YAAAAASUVORK5CYII=" />`);
} else { 
if(document.querySelector("link[rel*='shortcut icon']")) document.querySelector("link[rel*='shortcut icon']").remove();
if(document.querySelector('link[href="assets://themes/dark.css"]')) document.querySelector('link[href="assets://themes/dark.css"]').remove();
document.head.insertAdjacentHTML('beforeend',`<link rel="shortcut icon" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAADE0lEQVR4Ae1YD4QiYRR/GAxCOCwOIYQQwmKxLA4hhLA4hEMIYREW4RBCWCwOYXH+h0UIh7AIixBCWBxCCIO7wQ/jZ95rvhprMD8e6s287/1/7xtJFTly5BiF9O8E9SWjKLOyBnmSQXxzMKAiGUTXwYCGZBBjUvJnSCXQC/F6kkHMSMlWhPdAvIl8Im5DesOh1Ri+D4/uo0rSs23i7UL6rhTzdUi/QlpeXCtQbkOHL3G4j1zeKXnuR+TUlWfWULiIGnon/h+5EAOjEA8Gb0dyisazQUhHg38vZ+LKUlKhPYZZRUsNS1nDGb6cgSkJ4oOZ9whPJ3HM0wlZAf03FEdcxwjuhFRCe/yI/P+OgnXFHclZY834gjPYqJI4YEkCVtQxvJDaOKgQs1IMIWMLWqCermKiMYYxURSixoFeJCEaMd6fQagFD602OJEeg4Rp9sbvJ410lV+MpErZUH7hUJhT0VFXWnOA9EqEhtKBDuAxnsFPTEokOkoEP1CXTihHBwtRPfJcTWl9HUSzpkzqI9VESzlrQc85ocDtFFQ1vL9V2mkpxojBidobpXN3oLBSQW+J1xQdPfauUXsbSRHsGYtnDbMaR4siRLx04DkaYLXbirEzfTV4F+NobJo8cO5ER4c3W8O4dVreH564006Vqc0oxvT3oXGnDrBinwcMjbnS2m7owsP8FSJRgOLNmGIPaDDeG0PPSEv3adg3rpMuNLGifXoLsAvtqEzDW2NerB2UXxj9valsAXurw7EAfnmZYBoWEkbiGcpbKCsOqSUtXH55rqRZl5VBlKbUnbZQvKZ8EKjG6LCxdXD/ytaEl3/Qqju3o2N6eUVp1YZRfa49GOmEVxLyl3YZ5uEziY2IggdDFvOe5EwPBY6dZQPlisol5YFSyyYu3lQ/l9u0sxdCJ7pomBXhMVbuEbtL10gFn6KppUsLrXuE39z/PbkQTQieYWf3lIs5z46q0RT2ymcYH4W8gONu5BPxatwLekZRZgYTUrJv8jIH9rJNTckgGg4GVCWDqDgY4EsG4YX0O4HyY8mRI0dq+A+K97sNa67IwAAAAABJRU5ErkJggg==" />`);
}
}
xloadThemes();
/* Tema Çek Yükle Son */

/* Ön Bellekten Arama Motorlarını Getir */
const searchEngines = sendSync('store', 'get', 'searchEngines').map(e => e.name);

/* Belirli Bir Div İçine Verileri Çek Yükle */
function loadDataEngines(oneID,twoID,theFuc){
let panelEl = document.getElementById(oneID);
let options = searchEngines.map(op => `<div class="sc-1k8lovv hJBLHH" onclick="${theFuc}('${op}', '${op}', '${twoID}')">${op}</div>`).join('\n');
panelEl.innerHTML += `${ options }`;
}

/* Arama Motorlarını Çek */
loadDataEngines('search-engine','search_engine-text','prossSearchEngines');

/* İç İşlem Pencere Değiştir */
function openContentViews(contentID,tabsID){
//'content-views-1', 'content-tabs-1'
document.getElementById('content-views-1').style.display = "none";
document.getElementById("content-tabs-1").classList.remove('bEUiyY');
document.getElementById('content-views-2').style.display = "none";
document.getElementById("content-tabs-2").classList.remove('bEUiyY');
document.getElementById('content-views-3').style.display = "none";
document.getElementById("content-tabs-3").classList.remove('bEUiyY');
document.getElementById('content-views-4').style.display = "none";
document.getElementById("content-tabs-4").classList.remove('bEUiyY');
document.getElementById('content-views-5').style.display = "none";
document.getElementById("content-tabs-5").classList.remove('bEUiyY');
document.getElementById('content-views-6').style.display = "none";
document.getElementById("content-tabs-6").classList.remove('bEUiyY');
document.getElementById('content-views-7').style.display = "none";
document.getElementById("content-tabs-7").classList.remove('bEUiyY');

var elementIdBul_content = document.getElementById(contentID);
var elementIdBul_tabs = document.getElementById(tabsID);

if(elementIdBul_content && elementIdBul_tabs){
elementIdBul_content.style.display = "block";
elementIdBul_tabs.classList.add('bEUiyY');
}
}

/* Select Gibi Yeni Modal Pencere Aç */
function openPopupModals(idElementx,closeEvents){
var elementIdBul = document.getElementById(idElementx);
var elementIdCloseEv = document.getElementById('closedEventAd');

if(elementIdBul){ 
var displayElements = elementIdBul.style;
if(!closeEvents){
if(displayElements.display == 'none'){
displayElements.display = "block";
elementIdCloseEv.style.display = "block";
} else { 
displayElements.display = "none"; 
elementIdCloseEv.style.display = "none";
}
} else { if(displayElements.display == 'block'){ displayElements.display = "none"; elementIdCloseEv.style.display = "none"; } }
}
}

/* Açık Select Gibi Olan Modalları Kapat */
function closeEventBodyAll(){
openPopupModals('ust-cubuk',true);
openPopupModals('theme-color',true);
openPopupModals('search-engine',true);
openPopupModals('chs-lang',true);
}

/* Üst Çubuk Varyant Değiştirme İşlemi */
function prossUstCubukVariant(eValue, eText, idElementxText){
var elementIdTextBul = document.getElementById(idElementxText);
if(elementIdTextBul){
elementIdTextBul.innerHTML = eText; 
send('store', 'set', 'settings.'+'headerView', eValue);
sendSync('loadHeaderViews');
window.location.reload(); 
}
}

/* Dil Değiştirme İşlemi */
function prossLangChanges(eValue, eText, idElementxText){
var elementIdTextBul = document.getElementById(idElementxText);
if(elementIdTextBul){
elementIdTextBul.innerHTML = eText; 
send('store', 'set', 'settings.'+'langs', eValue);
//sendSync('loadHeaderViews');
window.location.reload(); 
}
}

/* Tema Değiştirme İşlemi */
function prossTemaRengi(eValue, eText, idElementxText){
var elementIdTextBul = document.getElementById(idElementxText);
if(elementIdTextBul){
elementIdTextBul.innerHTML = eText;
send('store', 'set', 'settings.'+'theme', eValue);
sendSync('loadThemeNews');
xloadThemes();
window.location.reload(); 
}
}

/* Arama Motoru Değiştirme İşlemi */
function prossSearchEngines(eValue, eText, idElementxText){
var elementIdTextBul = document.getElementById(idElementxText);
if(elementIdTextBul){
elementIdTextBul.innerHTML = eText; 
send('store', 'set', 'settings.'+'search_engine', eValue);
}
}

/* Kayıtlı Tüm Ayarları Çek Yazdır */
async function loadSettings () {
let saved = sendSync('store', 'get', 'settings');
for (let [key, val] of Object.entries(saved)) {
let element = document.getElementById(key);

if(!element) continue;
let control = element.lastElementChild;

if(control.className != 'item-control-2'){
if(control.tagName == 'SELECT') {control.value = val;}
if(control.tagName == 'INPUT') { control.checked = val; }
}

/* Çoklu Değişkene Sahip Ayarlar Burada Örnek; Başlangıç Ayarları */
if(control.className == 'item-control-2'){
var get_key = document.getElementById('new-'+key+'-'+val);
if(get_key){get_key.checked = true;}
}

if(control.tagName == 'DIV') {

/*Tema Ayarları Özel*/
if(key == "theme"){
var intextkeys = document.getElementById(key+'-text'); 
if(intextkeys){ 
var namevalueNew = '';
if(val == "default"){ namevalueNew = i18n.__('Varsayılan'); }
if(val == "Light"){ namevalueNew = i18n.__('Açık'); }
if(val == "Dark"){ namevalueNew = i18n.__('Koyu'); }
intextkeys.innerHTML = namevalueNew;
} 
}
/*Tema Ayarları Özel Son*/

/*Üst çubk header Ayarları Özel*/
if(key == "headerView"){
var intextkeys = document.getElementById(key+'-text'); 
if(intextkeys){ 
var namevalueNew = '';
if(val == "default"){ namevalueNew = i18n.__('Tam'); }
if(val == "compact"){ namevalueNew = i18n.__('Kompakt'); }
intextkeys.innerHTML = namevalueNew;
} 
}
/*Üst çubk header Ayarları Özel Son*/

/*Dil Ayarları Özel*/
if(key == "langs"){
var intextkeys = document.getElementById(key+'-text'); 
if(intextkeys){ 
var namevalueNew = val;
if(val == "tr"){ namevalueNew = 'Turkish'; }
if(val == "en"){ namevalueNew = 'English'; }
if(val == "ru"){ namevalueNew = 'Russian'; }
if(val == "de"){ namevalueNew = 'German'; }
if(val == "es"){ namevalueNew = 'Spanish'; }
if(val == "fr"){ namevalueNew = 'French'; }
intextkeys.innerHTML = namevalueNew;
} 
}
/*Dil Ayarları Özel Son*/

/*Arama Motoru Ayarları Özel*/
if(key == "search_engine"){
var intextkeys = document.getElementById(key+'-text'); 
if(intextkeys){ 
intextkeys.innerHTML = val;
} 
}
/*Arama Motoru Ayarları Özel Son*/

}

}
}

/* Ayarları Değiştir Kaydet İşlemleri Canlandırma Radio buton için value iç değer kaydetme */
async function bindControls2 (controls2) {
for (let control2 of controls2) {
let key2 = control2.parentElement.id;
control2.addEventListener('click', () => send('store', 'set', 'settings.'+key2, control2.value));
}
}
bindControls2(document.getElementsByClassName('item-control-2'));

/* Ayarları Değiştir Kaydet İşlemleri Canlandırma */
async function bindControls (controls) {
for (let control of controls) {
let key = control.parentElement.id;
if(control.tagName == 'SELECT') {
control.addEventListener('change', () => send('store', 'set', 'settings.'+key, control.value));
}	else {    
control.addEventListener('click', () => send('store', 'set', 'settings.'+key, control.checked));
}
}
}

bindControls(document.getElementsByClassName('item-control'));
loadSettings();

/* Bayrakları Döndür */
const getFlags = sendSync('store', 'get', 'flags').map(e => e);
/* Belirli Bir Div İçine Verileri Çek Yükle */
function loadDataFlags(oneID,twoID){
let panelEl = document.getElementById(oneID);
let options = getFlags.map(op => `
<div class="sc-l5yqk8 jInefD">
<div class="sc-v03tst epMHXf">${op}</div>
<div class="sc-ur64yn gINTBr" id="${op}">
<input id="${op}" disabled checked type="checkbox" class="switch item-control-x">
</div>
</div>
`).join('\n');
panelEl.innerHTML += `${ options }`;
}

loadDataFlags('flags','flags-text');
/* Bayrakları Döndür Son */



/* Dilleri Döndür */
const getLangPacs = sendSync('store', 'get', 'langAllPack').map(e => e);
/* Belirli Bir Div İçine Verileri Çek Yükle */
function loadDataLangs(oneID,twoID){
let panelEl = document.getElementById(oneID);
let options = getLangPacs.map(op => 
`
<div class="sc-1k8lovv hJBLHH" onclick="prossLangChanges('${op}', '${op}', 'langs-text')">${op}</div>
`).join('\n');
panelEl.innerHTML += `${ options }`;
}

loadDataLangs('chs-lang','langs-text');
/* Dilleri Döndür Son */


/* Sürüm Bilgileri */
function getUserAgent() {return navigator.userAgent;}
function setVersions(versions) {
document.getElementById('user-agent').innerHTML = getUserAgent();
document.getElementById('chrome').innerHTML = versions.chrome;
document.getElementById('node').innerHTML = versions.node;
document.getElementById('electron').innerHTML = versions.electron;
document.getElementById('holla').innerHTML = versions.holla;
}
setVersions(sendSync('getVersions'));


async function openLoadURL (urls) {
window.location.href = urls;
}

async function openLoadURLEx (urls) {
sendSync('openPageNews', urls);
}

let leftMenuAffters = document.getElementById('ayarlar');
if(leftMenuAffters){ leftMenuAffters.classList.add('bEUiyY'); }

/* Git Infos */
var getJSON = function(url, callback) {
var xhr = new XMLHttpRequest();
xhr.open('GET', url, true);
xhr.responseType = 'json';
xhr.onload = function() {
var status = xhr.status;
if (status === 200) {
callback(null, xhr.response);
} else {
callback(status, xhr.response);
}
};
xhr.send();
};
getJSON('https://api.github.com/repos/meforce/holla/releases/latest',
function(err, data) {
if (err !== null) {
document.getElementById('defaultSoftWare').style.display = 'block'; 
} else {
if(!data.draft){
document.getElementById('defaultSoftWare').style.display = 'none'; 
document.getElementById('GithubsSoftWare').style.display = 'block'; 
document.getElementById('hollaGen').innerText = sendSync('getVersions').holla;

document.getElementById('hollaYayiym').innerText = data.name;
if(data.body.trim()){ document.getElementById('dahamasosss').style.display = 'block';  }
document.getElementById('softhakkinda').innerHTML = data.body.replace(/\n/g, "<br />");

document.getElementById('githuburlss').innerHTML = `<a onclick="openLoadURLEx('${data.html_url}')">${data.html_url}</a>`;

if(data.name <= sendSync('getVersions').holla){ 
document.getElementById('sfotGuncelss').style.display = 'block'; 
document.getElementById('sfotGuncelssDegil').style.display = 'none'; 
document.getElementById('sfotGuncelss').innerHTML = `<div onclick="openLoadURLEx('${data.html_url}')" class="sc-v03tst epMHXf" id="sfotGuncelssx">${i18n.__('Sistem Güncel, Son Sürüm Kullanıyor')}</div>`; 
} else {
document.getElementById('sfotGuncelssDegil').style.display = 'block'; 
document.getElementById('sfotGuncelss').style.display = 'none'; 
document.getElementById('sfotGuncelssDegil').innerHTML = `<div onclick="openLoadURLEx('${data.html_url}')" class="sc-v03tst epMHXf" id="sfotGuncelssDegilx">${i18n.__('Sistem Güncel Değil, Yazılımı Güncelle!')}</div>`; 
}

} else {
document.getElementById('defaultSoftWare').style.display = 'block'; 
document.getElementById('GithubsSoftWare').style.display = 'none'; 
}
} 
});